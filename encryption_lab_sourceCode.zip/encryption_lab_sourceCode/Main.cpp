#include<iostream>
#include<string>
#include<conio.h>
#include"TreeType.h"





int main()
{
	using namespace std;
	
	
	TreeType biTree;  //declared variables
	string teststring;
	bool found;
	char menu;
	int j = 0;



	do  //menu of options to do
	{
		cout << "What would you like to do." << endl;
		cout << "a. Enter a string for encryption." << endl;
		cout << "b. Enter an encryption to decode." << endl;
		cout << "c. Enter characters to delete from the encryption." << endl;
		cout << "d. Exit the program." << endl;
		cin >> menu;

		switch(menu)
		{
		case 'a':
			cout << "Input a string to encrypt." << endl;
			cin.get();
			getline(cin, teststring);
			for(int i = 0; i < teststring.size(); i++)  //make string all lower case
			{
				teststring[i] = tolower(teststring[i]);
			}
			cout << teststring << endl;
			for(int i = 0; i < teststring.size(); i++)  //put each element of string into a tree
				biTree.PutItem(teststring[i]);
			for(int i = 0; i < teststring.size(); i++)  //print encryption symbols for the previous string
			{
				biTree.GetItem(teststring[i], found);
			}
			cout << endl;
			cout << biTree.GetLength() << endl;  //show nodes of tree size
			break;
		case 'b':
			cout << "Input cryption key." << endl;
			cin.get();
			getline(cin, teststring);
			j = 0;  //couldn't find a better way to declare so it wasn't reset inside the function each time
			biTree.DecodeItem(teststring, j);  //take in symbols to decode from the current tree
			cout << endl;
			break;
		case 'c':
			cout << "Input characters to delete from the encryption." << endl;
			cin.get();
			getline(cin, teststring);
			for(int i = 0; i < teststring.size(); i++)  //make string all lower case
			{
				teststring[i] = tolower(teststring[i]);
			}
			cout << teststring << endl;
			for(int i = 0; i < teststring.size(); i++)  //delete each character from the tree
				biTree.DeleteItem(teststring[i]);
			cout << biTree.GetLength() << endl;  //show current nodes after deletion
			break;
		default:
			continue;
		}
	}
	while(menu != 'd');
	cout << endl << "Please press any key to exit ..." << endl;                           
	cin.sync();
	_getch();
	return 0;
}