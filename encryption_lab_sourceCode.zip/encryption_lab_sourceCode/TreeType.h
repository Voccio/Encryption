//TreeType.h & TreeType.cpp comes from the text book

#include<iostream>
using namespace std;

struct TreeNode;

typedef char ItemType;  //this week did't use ItemType, thinking now I could have made it to where
  // first name would hold the entire string and last name would hold the encryption string to decrypt

enum OrderType {PRE_ORDER, IN_ORDER, POST_ORDER};  //was removed for ease of use for this weeks lab, but this got left behind

class TreeType
{
public:
	TreeType();
	~TreeType();
	TreeType(const TreeType& originalTree);
	void operator= (const TreeType& originalTree);
	void MakeEmpty();
	bool IsFull() const;  //these not really a concern when using dynamic allocation unless we get the large
	bool IsEmpty() const;
	int GetLength() const;
	ItemType GetItem(ItemType item, bool& found) const;
	void PutItem(ItemType item);
	void DeleteItem(ItemType item);
	void ResetTree();  //don't think this is even defined, tried to use, but making the decoding a funtion of the TreeType was easier
	ItemType GetNextItem(OrderType order, bool& finished);  //not used and could be taken out
	void Print() const;
	void TreeType::DecodeItem(string code, int& i);  //functions added for decrypting incoming encryption
	void TreeType::Decode(TreeNode* tree, string code, int& i);



	TreeNode* root; //made private at a time to get testing functions working
};  //looks as though it could be redeclared as a private member for encapsulation

struct TreeNode
{
	ItemType info;
	TreeNode* left;
	TreeNode* right;
};