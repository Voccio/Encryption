//comes from the text, changes will be commented


#include"TreeType.h"

typedef char ItemType;

bool TreeType::IsFull() const
{
	TreeNode* location;
	try
	{
		location = new TreeNode;
		delete location;
		return false;
	}
	catch(std::bad_alloc exception)
	{
		return true;
	}
}

bool TreeType::IsEmpty() const
{
	return root == NULL;
}

int CountNodes(TreeNode* tree);

int TreeType:: GetLength() const
{
	return CountNodes(root);
}

int CountNodes(TreeNode* tree)
{
	if(tree == NULL)
		return 0;
	else return CountNodes(tree->left) + CountNodes(tree->right) + 1;
}

void Retrieve(TreeNode* tree, ItemType& item, bool& found);

ItemType TreeType::GetItem(ItemType item, bool& found) const  //GetItem and Retrieve have some changes so the out put of the
{  //string will be changed into the appropiate symbols for the encryption
	if(root->info == item)
		cout << '*';  //for the root
	Retrieve(root, item, found);
	cout << '!';  //delimiter
	return item;
}

void Retrieve(TreeNode* tree, ItemType& item, bool& found)
{
	if(tree == NULL)
	{
		found = false;
	}
	else if(item < tree->info)
	{
		cout << '<';  //if we go left
		Retrieve(tree->left, item, found);
	}
	else if(item > tree->info)
	{
		cout << '>';  //if we go right
		Retrieve(tree->right, item, found);
	}
	else
	{
		item = tree->info;
		found = true;
	}
}

void Insert(TreeNode*& tree, ItemType item);

void TreeType::PutItem(ItemType item)
{
	Insert(root, item);
}

void Insert(TreeNode*& tree, ItemType item)
{
	if(tree == NULL)
	{
		tree = new TreeNode;
		tree->right = NULL;
		tree->left = NULL;
		tree->info = item;
	}
	else if(item < tree->info)
		Insert(tree->left, item);
	else if(item > tree->info)
		Insert(tree->right, item);  //nodes was counting improperly until I noticed that it didn't account for nodes of the same value
	else if(item == tree->info){}  //made sure to do nothing if values ==
}

void GetPredecessor(TreeNode* tree, ItemType& data);

void DeleteNode(TreeNode*& tree);

void Delete(TreeNode*& tree, ItemType item);

void TreeType::DeleteItem(ItemType item)
{
	Delete(root, item);
}

void Delete(TreeNode*& tree, ItemType item)
{
	if(item < tree->info)
		Delete(tree->left, item);
	else if(item > tree->info)
		Delete(tree->right, item);
	else
		DeleteNode(tree);
}

void DeleteNode(TreeNode*& tree)
{
	ItemType data;
	TreeNode* tempPtr;

	tempPtr = tree;
	if(tree->left == NULL)
	{
		tree = tree->right;
		delete tempPtr;
	}
	else if(tree->right == NULL)
	{
		tree = tree->left;
		delete tempPtr;
	}
	else
	{
		GetPredecessor(tree->left, data);
		tree->info = data;
		Delete(tree->left, data);
	}
}

void GetPredecessor(TreeNode* tree, ItemType& item)
{
	while(tree->right != NULL)
		tree = tree->right;
	item = tree->info;
}

void PrintTree(TreeNode* tree)  //changed to display on screen, from saving to file
{
	if(tree != NULL)
	{
		PrintTree(tree->left);
		cout << tree->info;
		PrintTree(tree->right);
	}
}

void TreeType::Print() const
{
	PrintTree(root);
}

TreeType::TreeType()
{
	root = NULL;
}

void Destroy(TreeNode*& tree);

TreeType::~TreeType()
{
	Destroy(root);
}

void Destroy(TreeNode*& tree)
{
	if(tree != NULL)
	{
		Destroy(tree->left);
		Destroy(tree->right);
		delete tree;
	}
}

void TreeType::MakeEmpty()
{
	Destroy(root);
	root = NULL;
}

void CopyTree(TreeNode*& copy, const TreeNode* originalTree);

TreeType::TreeType(const TreeType& originalTree)
{
	CopyTree(root, originalTree.root);
}

void TreeType::operator= (const TreeType& originalTree)
{
	if(&originalTree == this)
		return;
	Destroy(root);
	CopyTree(root, originalTree.root);
}

void CopyTree(TreeNode*& copy, const TreeNode* originalTree)
{
	if(originalTree == NULL)
		copy = NULL;
	else
	{
		copy = new TreeNode;
		copy->info = originalTree->info;
		CopyTree(copy->left, originalTree->left);
		CopyTree(copy->right, originalTree->right);
	}
}



void TreeType::DecodeItem(string code, int& i)  //only here to reduce incoming arguements from main
{
	Decode(root, code, i);  //also here to start search from the root after the encryption directions were followed
}

void TreeType::Decode(TreeNode* tree, string code, int& i)
{
	
		for(i; i < code.size(); i)
		{
			if(code[i] == '*')  //if root only want to proceed to next symbol of encryption
			{
				i++;
			}
			else if(code[i] == '<')  //if left arrow move tree pointer to the left node
			{
				i++;
				if(tree != NULL)  //dont' bother if tree node doesn't exsist
					Decode(tree->left, code, i);  //recursive
			}
			else if(code[i] == '>')  //if right arrow move tree pointer to the right node
			{
				i++;
				if(tree != NULL)  //dont bother if tree node doesn't exsist
					Decode(tree->right, code, i);  //recursive
			}
			else if(code[i] == '!')  //delimiter to signify that we have reached the node we need to display
			{
				i++;
				if(tree != NULL)  //don't bother if node doesn't exsist
					cout << tree->info;
				else if(tree == NULL)  //if it doesn't exsist let them know
				{
					cout << "You have entered an invalid encryption sequence." << endl;
					cout << "Continuing with decryption." << endl;
				}
				Decode(root, code, i);  //continue decrypting / recursive call
			}
		}
}